
import pandas as pd
import matplotlib.pyplot as plt

# Read both CSV files
data65 = pd.read_csv(
    r"C:\Users\Satya\Documents\KiCad\EXERCISES\EX_0\L5\CMOS_Inverter_65nm.csv", sep="\t")
data_discrete = pd.read_csv(
    r"C:\Users\Satya\Documents\KiCad\EXERCISES\EX_0\L5\CMOS_Inv.csv", sep="\t")

# Supply voltages
VDD_65 = 1.1
VDD_discrete = 5.0

# 65 nm inverter
Vin65 = data65["V(vin)"] / VDD_65
Vout65 = data65["V(vout)"] / VDD_65

# Discrete inverter
Vin_discrete = data_discrete["VIN"] / VDD_discrete
Vout_discrete = data_discrete["V(vout)"] / VDD_discrete

# Plot normalized curves
plt.plot(Vin65, Vout65, label="65 nm Inverter")
plt.plot(Vin_discrete, Vout_discrete, label="Discrete Inverter")

# Labels and title
plt.xlabel("Normalized Input Voltage (VIN/VDD)")
plt.ylabel("Normalized Output Voltage (VOUT/VDD)")
plt.title("Normalized Voltage Transfer Curve")

# Formatting
plt.grid(True)
plt.legend()
plt.xlim(0, 1)
plt.ylim(0, 1.1)

plt.show()
