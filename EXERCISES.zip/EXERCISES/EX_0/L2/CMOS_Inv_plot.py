
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Read CSV file
data = pd.read_csv(
    r"C:\Users\Satya\Documents\KiCad\EXERCISES\EX_0\L2\CMOS_Inv.csv", sep="\t")

# Remove extra spaces from column names
data.columns = data.columns.str.strip()

# Extract input and output voltages
Vin = data["VIN"]
Vout = data["V(vout)"]

# Supply voltage
VDD = 5

# Output voltage at switching threshold
Vhalf = VDD / 2

# Find Vm using interpolation
Vm = np.interp(Vhalf, Vout[::-1], Vin[::-1])

# Plot voltage transfer curve
plt.plot(Vin, Vout, label="Vout vs Vin")

# Mark VDD/2
plt.axhline(Vhalf, color="red", linestyle="--",
            label="VDD/2 = 2.5 V")

# Mark switching threshold Vm
plt.axvline(Vm, color="green", linestyle="--",
            label=f"Vm = {Vm:.3f} V")

# Mark intersection point
plt.plot(Vm, Vhalf, "ro")

# Label the switching point
plt.annotate(
    f"Vm = {Vm:.3f} V",
    xy=(Vm, Vhalf),
    xytext=(Vm + 0.3, Vhalf + 0.8),
    arrowprops=dict(arrowstyle="->")
)

# Axis labels
plt.xlabel("Input Voltage Vin (V)")
plt.ylabel("Output Voltage Vout (V)")

# Title
plt.title("CMOS Inverter Voltage Transfer Curve")

# Grid and legend
plt.grid(True)
plt.legend()

# Display graph
plt.show()
